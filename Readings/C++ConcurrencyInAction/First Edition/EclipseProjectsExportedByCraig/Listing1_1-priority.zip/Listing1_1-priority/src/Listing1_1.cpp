// Listing1_1 but with priorities
// pthread support by W. Craig Scratchley and Eton Kan

#include <iostream>
//#include <thread>
#include "posixThread.hpp"

using namespace std;
using namespace pthreadSupport;

void hello()
{
    cout<<"Hello Concurrent World\n";
}

void main2()
{
    posixThread t(SCHED_FIFO, 50, hello); // lower priority
//    std::thread t(hello);
    t.join();
}

int main()
{
    try {       // ... realtime policy.
        // program is started off at realtime priority 99
        pthreadSupport::setSchedPrio(60); // drop priority down somewhat.
        main2();
        return 0;
    }
    catch (system_error& error) {
        cout << "Error: " << error.code() << " - " << error.what() << '\n';
        cout << "Have you launched process with a realtime scheduling policy?" << endl;
        return error.code().value();
    }
    catch (...) { throw; }
}
